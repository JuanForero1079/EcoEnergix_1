import FondoSlider from "../../Componentes/FondoSlider";

export default function HomeUsuario() {
  return (
    <section className="relative w-full min-h-screen flex items-center justify-center text-center px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* 🔹 Fondo igual al del Home principal */}
      <FondoSlider />

      {/* 🔹 Capa oscura encima del fondo */}
      <div className="absolute inset-0 bg-black/50" />

      {/* 🔹 Contenido centrado */}
      <div className="relative z-10 max-w-4xl mx-auto pt-20">
        <h1 className="text-3xl sm:text-5xl md:text-6xl font-extrabold text-white drop-shadow-lg mb-4">
          ¡Hola,{" "}
          <span className="bg-gradient-to-r from-[#4375b2] via-[#5f54b3] to-[#3dc692] bg-clip-text text-transparent drop-shadow-md">
            Usuario
          </span>
          !
        </h1>
        <p className="text-base sm:text-lg md:text-xl text-gray-200 mb-8">
          Bienvenido a tu panel personal de{" "}
          <span className="font-semibold text-[#3dc692]">EcoEnergix</span>.  
          Gestiona tus compras, perfil y servicios solares desde un solo lugar.
        </p>

        {/* 🔹 Botones idénticos en estilo a los del Home */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-6">
          <a
            href="/usuario/catalogo"
            className="w-full sm:w-auto px-6 py-3 bg-[#3dc692] text-white rounded-lg font-semibold shadow-md hover:bg-[#5f54b3] transition"
          >
            Ver Catálogo
          </a>
          <a
            href="/usuario/compras"
            className="w-full sm:w-auto px-6 py-3 bg-[#5f54b3] text-white rounded-lg font-semibold shadow-md hover:bg-[#3dc692] transition"
          >
            Mis Compras
          </a>
          <a
            href="/usuario/perfil"
            className="w-full sm:w-auto px-6 py-3 bg-[#4375b2] text-white rounded-lg font-semibold shadow-md hover:bg-[#3dc692] transition"
          >
            Mi Perfil
          </a>
        </div>
      </div>
    </section>
  );
}
