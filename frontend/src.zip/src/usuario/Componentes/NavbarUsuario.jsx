import React from "react";
import { Link } from "react-router-dom";

const NavBarUsuario = () => {
  return (
    <nav className="fixed top-0 left-0 w-full bg-black/70 backdrop-blur-md text-white shadow-md z-50">
      <div className="max-w-7xl mx-auto flex justify-between items-center p-4">
        <h2 className="text-2xl font-bold text-teal-400">Ecoenergix</h2>
        <ul className="flex space-x-6">
          <li>
            <Link to="/homeusuario" className="hover:text-teal-400 transition">
              Inicio
            </Link>
          </li>
          <li>
            <Link to="/perfil" className="hover:text-teal-400 transition">
              Perfil
            </Link>
          </li>
          <li>
            <Link to="/compras" className="hover:text-teal-400 transition">
              Mis Compras
            </Link>
          </li>
          <li>
            <Link to="/" className="hover:text-red-400 transition">
              Cerrar Sesión
            </Link>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default NavBarUsuario;
