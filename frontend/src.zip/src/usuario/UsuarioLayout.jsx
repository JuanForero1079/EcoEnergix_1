import { Outlet } from "react-router-dom";
import NavbarUsuario from "./Componentes/NavbarUsuario.jsx";

export default function UsuarioLayout() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-100">

      <NavbarUsuario />


      <main className="flex-grow">
        <Outlet />
      </main>
    </div>
  );
}